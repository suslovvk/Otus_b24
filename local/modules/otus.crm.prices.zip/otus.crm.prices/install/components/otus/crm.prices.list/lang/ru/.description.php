<?php
$MESS['OTUS_PRICES_COMPONENT_NAME'] = 'Список цен';
$MESS['OTUS_PRICES_COMPONENT_DESCRIPTION'] = 'Компонент для отображения списка цен в CRM';