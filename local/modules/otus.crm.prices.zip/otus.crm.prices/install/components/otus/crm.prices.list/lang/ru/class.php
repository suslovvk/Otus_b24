<?php
$MESS['OTUS_PRICES_GRID_NAME'] = 'Название';
$MESS['OTUS_PRICES_GRID_PRICE'] = 'Цена';
$MESS['OTUS_PRICES_GRID_ACTIVE'] = 'Активность';