<?php
$MESS['OTUS_PRICES_INSTALL_MODULE_NAME'] = 'Управление ценами';
$MESS['OTUS_PRICES_INSTALL_MODULE_DESCRIPTION'] = 'Модуль для управления ценами и услугами в CRM';
$MESS['OTUS_PRICES_PARTNER_NAME'] = 'OTUS';
$MESS['OTUS_PRICES_PARTNER_URI'] = 'https://otus.ru';
$MESS['OTUS_PRICES_INSTALL_ERROR_VERSION'] = 'Требуется версия Битрикс D7 или выше';