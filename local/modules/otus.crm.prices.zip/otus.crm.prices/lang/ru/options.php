<?php
$MESS['OTUS_PRICES_OPTIONS_TAB_SETTINGS'] = 'Настройки';
$MESS['OTUS_PRICES_OPTIONS_TAB_SETTINGS_TITLE'] = 'Настройки модуля';
$MESS['OTUS_PRICES_OPTIONS_NO_SETTINGS'] = 'Модуль не требует настройки';