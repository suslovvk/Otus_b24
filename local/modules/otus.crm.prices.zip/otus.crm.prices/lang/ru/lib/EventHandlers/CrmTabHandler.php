<?php
$MESS['OTUS_PRICES_TAB_TITLE'] = 'Цены';